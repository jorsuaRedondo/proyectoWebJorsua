<?php
if(isset($_POST['submit'])) {
    $to = 'correo@ejemplo.com'; // Cambiar con la dirección de correo deseada
    $subject = 'Solicitud de cita'; // Asunto del correo electrónico

    // Obtener los datos del formulario
    $nombre = $_POST['nombre'];
    $identificacion = $_POST['id'];
    $correo = $_POST['correo'];
    $animal = $_POST['nombreR'];
    $otros = $_POST['otros'];
    $consulta = $_POST['cons'];
    $atencion = $_POST['atencion'];
    $fecha = $_POST['fecha'];
    $hora = $_POST['hora'];
    $anotaciones = $_POST['anotaciones'];

    // Construir el mensaje del correo electrónico
    $message = "Nombre: $nombre\n\n";
    $message .= "Identificación: $identificacion\n\n";
    $message .= "Correo electrónico: $correo\n\n";
    $message .= "Tipo de animal: $animal\n\n";
    $message .= "Otros: $otros\n\n";
    $message .= "Tipo de consulta: $consulta\n\n";
    $message .= "Tipo de atención: $atencion\n\n";
    $message .= "Fecha: $fecha\n\n";
    $message .= "Hora: $hora\n\n";
    $message .= "Anotaciones: $anotaciones\n\n";

    // Enviar el correo electrónico
    if(mail($to, $subject, $message)) {
        echo 'El correo electrónico fue enviado correctamente.';
    } else {
        echo 'Ocurrió un error al enviar el correo electrónico.';
    }
}
?>
